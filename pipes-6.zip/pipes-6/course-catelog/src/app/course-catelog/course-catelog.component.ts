import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Course } from './course.model';

@Component({
  selector: 'app-course-catelog',
  imports: [CommonModule],
  templateUrl: './course-catelog.component.html',
  styleUrl: './course-catelog.component.css'
})
export class CourseCatalogComponent {
  courses: Course[] = [
    {
      id: 1,
      title: 'Angular Masterclass',
      instructor: 'John Doe',
      startDate: new Date(2025, 6, 15),
      price: 4999.99,
      description: 'Comprehensive guide to Angular framework with hands-on labs and projects.'
    },
    {
      id: 2,
      title: 'Web Development Basics',
      instructor: 'Jane Smith',
      startDate: new Date(2025, 7, 10),
      price: 2999.00,
      description: 'Learn HTML, CSS, and JavaScript from scratch with real examples.'
    }
  ];
}
