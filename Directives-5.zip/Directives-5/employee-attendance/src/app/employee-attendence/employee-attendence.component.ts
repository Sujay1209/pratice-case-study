import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Employee } from './employee.model';

@Component({
  selector: 'app-employee-attendence',
  imports: [CommonModule],
   templateUrl: './employee-attendance.component.html',
  styleUrls: ['./employee-attendance.component.css']
})
export class EmployeeAttendanceComponent {
  employees: Employee[] = [
    { name: 'Alice', department: 'IT', isPresent: true, workFromHome: false },
    { name: 'Bob', department: 'Sales', isPresent: true, workFromHome: true },
    { name: 'Charlie', department: 'HR', isPresent: false, workFromHome: false }
  ];
}
