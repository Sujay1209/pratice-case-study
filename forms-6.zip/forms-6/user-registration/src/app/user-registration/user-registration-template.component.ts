import { Component } from '@angular/core';
import { UserRegistration } from './user-registration.model';
import { CommonModule } from '@angular/common';
import { FormsModule, NgForm } from '@angular/forms';

@Component({
  selector: 'app-user-registration',
  imports: [CommonModule, FormsModule],
  templateUrl: './user-registration.html',
  styleUrl: './user-registration.css'
})
export class UserRegistrationTemplateComponent {
  user: UserRegistration = {
    fullName: '',
    email: '',
    gender: '',
    country: '',
    agreeToTerms: false
  };
  submitted = false;

  onSubmit(form: NgForm): void {
    if (form.valid) {
      this.submitted = true;
      console.log('Submitted:', this.user);
    } else {
      console.log('Form is invalid');
    }
  }
}
