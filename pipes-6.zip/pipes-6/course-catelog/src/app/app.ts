import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Course } from './course-catelog/course.model';
import { CourseCatalogComponent } from './course-catelog/course-catelog.component';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,CourseCatalogComponent],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected title = 'course-catelog';
}
