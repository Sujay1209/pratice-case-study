import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Student } from './student.model';

@Component({
  selector: 'app-student-list',
  imports: [CommonModule],
  templateUrl: './student-list.component.html',
  styleUrl: './student-list.component.css'
})
export class StudentListComponent {
  students: Student[] = [
    { name: 'Alice', marks: 75, isActive: true },
    { name: 'Bob', marks: 45, isActive: false },
    { name: 'Charlie', marks: 85, isActive: true },
    { name: 'David', marks: 30, isActive: true }
  ];
}
