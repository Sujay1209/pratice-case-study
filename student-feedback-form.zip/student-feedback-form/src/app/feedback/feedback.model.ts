export interface StudentFeedback {
  studentName: string;
  course: string;
  rating: number;
  comments: string;
}
