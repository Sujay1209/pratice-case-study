export interface Student {
  name: string;
  marks: number;
  isActive: boolean;
}