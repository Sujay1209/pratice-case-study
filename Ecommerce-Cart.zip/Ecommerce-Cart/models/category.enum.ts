export enum Category {
    Electronics = "Electronics",
    Clothing = "Clothing",
    Grocery = "Grocery"
}
