export interface Course {
  id: number;
  title: string;
  instructor: string;
  startDate: Date;
  price: number;
  description: string;
}
