export interface Employee {
  name: string;
  department: string;
  isPresent: boolean;
  workFromHome: boolean;
}
