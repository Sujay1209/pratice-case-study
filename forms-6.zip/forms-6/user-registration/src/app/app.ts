import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { UserRegistrationTemplateComponent } from './user-registration/user-registration-template.component';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,UserRegistrationTemplateComponent],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected title = 'user-registration';
}
