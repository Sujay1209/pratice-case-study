export interface UserRegistration {
  fullName: string;
  email: string;
  gender: string;
  country: string;
  agreeToTerms: boolean;
}